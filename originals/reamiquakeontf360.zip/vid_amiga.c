/*
Copyright (C) 1996-1997 Id Software, Inc.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 
*/


// Amiga includes.
#include <proto/exec.h>
#include <proto/intuition.h>
#include <proto/graphics.h>

#include "amiga_c2p_aga.h"

#include "quakedef.h"
#include "d_local.h"
#include "vid_amiga.h"
 




/** Hardware window */
struct Window *_hardwareWindow = NULL;

/** Hardware screen */
static struct Screen *_hardwareScreen = NULL;




static UWORD _emptypointer[] = {
  0x0000, 0x0000,    /* reserved, must be NULL */
  0x0000, 0x0000,     /* 1 row of image data */
  0x0000, 0x0000    /* reserved, must be NULL */
};


static int video_depth = 8;


static struct ScreenBuffer *sbuffer[2] = {NULL, NULL};
void *c2p[2] = {NULL, NULL};

static BYTE _currentScreenBuffer = 0;





unsigned short	d_8to16table[256];	// not used in 8 bpp mode
unsigned		d_8to24table[256];	// not used in 8 bpp mode

static byte		*vid_surfcache = NULL;
static int		vid_highhunkmark = 0;

static pixel_t *vid_buffer = NULL;

byte	vid_current_palette[768];	// save for mode changes

void VID_MenuDraw (void);
void VID_MenuKey (int key);
void M_DrawCharacter (int cx, int line, int num);
void M_Print (int cx, int cy, char *str);
void M_PrintWhite (int cx, int cy, char *str);
void M_DrawPic (int x, int y, qpic_t *pic);
void M_Menu_Options_f (void);








//
// base mode descriptors, in ascending order of number of pixels
//
vmode_t	palVideoModes[] = {
{
	NULL,
	"320x200",
	320, 200, (200.0/320.0)*(320.0/240.0),
    320, 2
},
{
	NULL,
	"320x240",
    320, 240, (240.0/320.0)*(320.0/240.0),
	320, 2
},
{
	NULL,
	"320x256",
    320, 256, (256.0/320.0)*(320.0/240.0),
	320, 2
}
};

vmode_t	ntscVideoModes[] = {
{
	NULL,
	"320x200",
	320, 200, (200.0/320.0)*(320.0/240.0),
    320, 2
}, 
{
	NULL,
	"640x200",
    640, 200, (200.0/640.0)*(320.0/240.0),
	640, 2
},
{
	NULL,
	"1280x200",
    1280, 200, (200.0/1280.0)*(320.0/240.0),
	1280, 2
}
};


/*vmode_t	vgaVideoModes[] = {
{
	NULL,
	"320x200",
	320, 200, (200.0/320.0)*(320.0/240.0),
    320, 2
},
{
	NULL,
	"320x240",
    320, 240, (240.0/320.0)*(320.0/240.0),
	320, 2
},
{
	NULL,
	"640x480",
    640, 480, (480.0/640.0)*(320.0/240.0),
	640, 2
}
};*/

/*vmode_t	rtgVideoModes[] = {
{
	NULL,
	"320x200",
	320, 200, (200.0/320.0)*(320.0/240.0),
    320, 1
},
{
	NULL,
	"320x240",
    320, 240, (240.0/320.0)*(320.0/240.0),
	320, 1
},
{
	NULL,
	"640x480",
    640, 480, (480.0/640.0)*(320.0/240.0),
	640, 1
},
{
	NULL,
	"800x600",
    800, 600, (600.0/800.0)*(320.0/240.0),
	800, 1
},
{
	NULL,
	"1024x768",
    1024, 768, (768.0/1024.0)*(320.0/240.0),
	1024, 1
},
{
	NULL,
	"1280x720",
    1280, 720, (720.0/1280.0)*(320.0/240.0),
	1280, 1
}
};*/
 




static DisplayType_t _displayType;
static char _displayTypeName[5];

static unsigned numVideoModes = 0;
static vmode_t *videoModes = NULL;

static unsigned	currentVideoModeIndex = 0;
static unsigned	defaultVideoModeIndex = 0;

static vmode_t	*currentVideoMode = NULL; 


#define DEFAULT_AGA_VIDEO_MODE_INDEX 0







void VID_SetPalette (unsigned char *palette)
{
  int i;
  ULONG v;
  static ULONG colourtable[1+3*256+1];
  
    // Save a copy of the palette for mode changes.
    if (palette != vid_current_palette) {
		Q_memcpy(vid_current_palette, palette, 768);
    }
  

  colourtable[0] = (256 << 16) + 0;
  for (i = 0; i < 3*256; i++) {
    v = *palette++;
    v += (v << 8);
    v += (v << 16);
    colourtable[i+1] = v;
  }
  
  colourtable[1 + 3*256] = 0;
  LoadRGB32(&_hardwareScreen->ViewPort, colourtable);
}

void	VID_ShiftPalette (unsigned char *palette)
{
  VID_SetPalette (palette);
}



/*
=================
VID_GetModePtr
=================
*/
vmode_t *VID_GetModePtr (unsigned modenum)
{
	vmode_t	*pv;

	pv = videoModes;
	if (!pv) {
		Sys_Error ("VID_GetModePtr: empty video mode list");
    }
    
	while (modenum--)
	{
		pv = pv->pnext;
		if (!pv) {
			Sys_Error ("VID_GetModePtr: Corrupt video mode list detected");
        }
	}

	return pv;
}

void VID_UnloadGFXMode(void) {
    
    int i;
    
    if (currentVideoMode == NULL) {
        // Nothing to do.
        return;
    }
      
    if (_hardwareWindow) {
        ClearPointer(_hardwareWindow);
        CloseWindow(_hardwareWindow);
        _hardwareWindow = NULL;
    }
    

    if (sbuffer[0] != NULL) {
        ChangeScreenBuffer (_hardwareScreen, sbuffer[0]);
        WaitTOF();
        WaitTOF();
        FreeScreenBuffer (_hardwareScreen, sbuffer[0]);
        sbuffer[0] = NULL;
    }
    
    if (sbuffer[1] != NULL) {
        FreeScreenBuffer (_hardwareScreen, sbuffer[1]);
        sbuffer[1] = NULL;
    }
    

    if (_hardwareScreen) {
        CloseScreen(_hardwareScreen);
        _hardwareScreen = NULL;
    }
    
    if (vid_buffer) {
        free(vid_buffer);
        vid_buffer = NULL;
    }  
    
    if (c2p[0]) {
        c2p8_deinit_stub(c2p[0]);
        c2p[0] = NULL;
    }
    
    if (c2p[1]) {
        c2p8_deinit_stub(c2p[1]);
        c2p[1] = NULL;
    }          
}



struct Screen* VID_CreateHardwareScreenAGA(unsigned width, unsigned height) {

    // Create the hardware screen.
    struct Screen* screen = NULL;
	struct Rectangle clip;
    ULONG modeId = INVALID_ID;
    ULONG monitorId = PAL_MONITOR_ID;
    
    if (_displayType == NTSC_DISPLAY_TYPE) {
        monitorId = NTSC_MONITOR_ID;
    }
    

	// Setup clip region.
	clip.MinX = 0;
    clip.MinY = 0;
    clip.MaxX = width - 1;
    clip.MaxY = height - 1;

    modeId = BestModeID(BIDTAG_NominalWidth, width,
                        BIDTAG_NominalHeight, height,
            	        BIDTAG_DesiredWidth, width,
            	        BIDTAG_DesiredHeight, height,
            	        BIDTAG_Depth, video_depth,
            	        BIDTAG_MonitorID, monitorId,
						//BIDTAG_DIPFMustHave, DIPF_IS_DBUFFER,
						//BIDTAG_DIPFMustNotHave, DIPF_IS_HAM,
            	        TAG_END);

    if (modeId != INVALID_ID) {
    	screen = (struct Screen*) OpenScreenTags(NULL,
                         SA_Depth, video_depth,
                         SA_DisplayID, modeId,
                         SA_Width, width,
    					 SA_Height, height,
                         SA_DClip, (ULONG)&clip,
						 SA_Type, CUSTOMSCREEN,
                         SA_Quiet, TRUE,
    					 SA_ShowTitle, FALSE,
    					 SA_Draggable, FALSE,
                         SA_Exclusive, TRUE,
    					 SA_AutoScroll, FALSE,
						 TAG_END);
    }

    return screen;
}

struct Window* VID_CreateHardwareWindow(unsigned width, unsigned height) {

    return OpenWindowTags(NULL,
                  	    WA_Left, 0,
            			WA_Top, 0,
            			WA_Width, width,
            			WA_Height, height,
            			WA_Title, NULL,
            			WA_CustomScreen, (ULONG)_hardwareScreen,
            			WA_Backdrop, TRUE,
            			WA_Borderless, TRUE,
            			WA_DragBar, FALSE,
            			WA_Activate, TRUE,
            			WA_SimpleRefresh, TRUE,
            			WA_NoCareRefresh, TRUE,
            			WA_ReportMouse, TRUE,
            			WA_RMBTrap, TRUE,
                  	    WA_IDCMP, IDCMP_RAWKEY|IDCMP_MOUSEMOVE|IDCMP_DELTAMOVE|IDCMP_MOUSEBUTTONS,
                  	    TAG_END);
}


qboolean VID_AllocBuffers (unsigned width, unsigned height)
{
	int		tsize, tbuffersize;

    tbuffersize = width * height * sizeof (*d_pzbuffer);

	tsize = D_SurfaceCacheForRes(width, height);

	tbuffersize += tsize;

	if (d_pzbuffer)
	{
		D_FlushCaches ();
		Hunk_FreeToHighMark (vid_highhunkmark);
		d_pzbuffer = NULL;
	}

	vid_highhunkmark = Hunk_HighMark();

	d_pzbuffer = Hunk_HighAllocName (tbuffersize, "video");

	vid_surfcache = (byte *)d_pzbuffer + width * height * sizeof (*d_pzbuffer);
	
    D_InitCaches(vid_surfcache, tsize);

	return true;
}


qboolean VID_LoadGFXMode(vmode_t *newVideoMode) {
    
	_hardwareScreen = VID_CreateHardwareScreenAGA(newVideoMode->width, newVideoMode->height);
	if (!_hardwareScreen) {
		return false;
	}

    sbuffer[0] = AllocScreenBuffer (_hardwareScreen, NULL, SB_SCREEN_BITMAP);
    sbuffer[1] = AllocScreenBuffer (_hardwareScreen, NULL, 0);

   
    c2p[0] = c2p8_reloc_stub(sbuffer[0]->sb_BitMap);
    c2p[1] = c2p8_reloc_stub(sbuffer[1]->sb_BitMap);

    _currentScreenBuffer = 1;

    
	// Create the hardware window.
	_hardwareWindow = VID_CreateHardwareWindow(newVideoMode->width, newVideoMode->height);
	if (!_hardwareWindow) {
		return false;
	}
    	
    // Hide WB mouse pointer.
	SetPointer(_hardwareWindow, _emptypointer, 1, 16, 0, 0);      
    
    // Allocate the buffers.
    return VID_AllocBuffers(newVideoMode->width, newVideoMode->height);
}




/*
================
VID_SetMode 
================
*/
int VID_SetMode(unsigned newVideoModeIndex, unsigned char *palette) {

	vmode_t	*newVideoMode;

	if (newVideoModeIndex >= numVideoModes) {
	   Sys_Error("VID_SetMode: Invalid video mode requested");
	}


    if (currentVideoMode != NULL) {
        if (newVideoModeIndex == currentVideoModeIndex) {
            // already in the desired mode
            return 1;
        }
    }
        

	newVideoMode = VID_GetModePtr(newVideoModeIndex);
	if (!newVideoMode) {
        Sys_Error ("VID_SetMode: Corrupt video mode list detected");
    }


    
    VID_UnloadGFXMode();
    
    
    if (!VID_LoadGFXMode(newVideoMode)) {
        if (currentVideoMode == NULL) {
            // Failed on initial mode.
            Sys_Error("VID_SetMode: Unable to set initial mode, probably because there's not enough memory available");
        }
        
        // Try to restore the old mode.
        if (!VID_LoadGFXMode(currentVideoMode)) {
            Sys_Error("VID_SetMode: Unable to restore old mode, probably because there's not enough memory available");
        }
        
        // Restore of old mode was successful. 
        VID_SetPalette(palette);   
        
        Sys_Printf ("Failed to set mode %d\n", newVideoMode);
        return 0;
    }
    
        
    // Setting a new mode was successful.     
    currentVideoMode = newVideoMode;
    currentVideoModeIndex = newVideoModeIndex;

    if (vid_buffer) {
        free(vid_buffer);
        vid_buffer = NULL;
    }

    if ((vid_buffer = (pixel_t *)malloc(sizeof(pixel_t) * currentVideoMode->width * currentVideoMode->height)) == NULL) {
      Sys_Error ("Out of memory");
    }
    
    vid.buffer = vid_buffer;
    
    vid.width = currentVideoMode->width;
	vid.height = currentVideoMode->height;
	vid.aspect = currentVideoMode->aspect;
	vid.rowbytes = currentVideoMode->rowbytes;
	vid.numpages = currentVideoMode->numpages;
	
	
	vid.colormap = host_colormap;
	vid.fullbright = 256 - LittleLong(*((int *)vid.colormap + 2048));
	
	vid.maxwarpwidth = WARP_WIDTH;
	vid.maxwarpheight = WARP_HEIGHT;
	
	vid.conbuffer = vid_buffer;
	vid.conrowbytes = currentVideoMode->rowbytes;
	vid.conwidth = currentVideoMode->width;
	vid.conheight = currentVideoMode->height;

    vid.recalc_refdef = 1;
    
    VID_SetPalette(palette);
    
    return 1;
}

unsigned VID_LoadDefaultMode() {
    
    int modeId = INVALID_ID;
    
    // Load mode file.
   	FILE *modeFile;
    char fileName[50];

    sprintf(fileName, "%s_default.mode", _displayTypeName); 

    modeFile = fopen(fileName, "r");
    if (modeFile != NULL) {
        fscanf(modeFile, "%u", &modeId);        
        fclose(modeFile); 
    }
        
    if ((modeId == INVALID_ID) || (modeId > (numVideoModes - 1))) {
        modeId = DEFAULT_AGA_VIDEO_MODE_INDEX;
    }
        
    return modeId;    
}

void VID_SaveDefaultMode(unsigned modeIndex) {
    
   	FILE *modeFile;
    char fileName[50];
    
    defaultVideoModeIndex = modeIndex;

    sprintf(fileName, "%s_default.mode", _displayTypeName);     
        
    modeFile = fopen(fileName, "w");
    if (modeFile != NULL) {
        fprintf(modeFile, "%u", defaultVideoModeIndex);
        fclose(modeFile);
    }
}


void VID_Update(vrect_t *rects) {
            
    c2p8_stub(c2p[_currentScreenBuffer], sbuffer[_currentScreenBuffer]->sb_BitMap, vid.buffer, vid.width * rects->height);
    
    if (ChangeScreenBuffer (_hardwareScreen, sbuffer[_currentScreenBuffer])) {
        // Flip.
	   _currentScreenBuffer = _currentScreenBuffer ^ 1;
    }
}

void VID_Init(unsigned char *palette, DisplayType_t displayType) {
    
    int i;


    _displayType = displayType;

    
    // link together all the display modes
    if (_displayType == PAL_DISPLAY_TYPE) {
        strcpy(_displayTypeName, "PAL");
        
        numVideoModes = (sizeof(palVideoModes) / sizeof(palVideoModes[0]));
        
        for (i = 0; i < (numVideoModes - 1) ; i++) {
            palVideoModes[i].pnext = &palVideoModes[i+1];
        }
        
        // Terminated the list.
        palVideoModes[numVideoModes - 1].pnext = NULL;
        
        // add the video modes at the start of the mode list
        videoModes = &palVideoModes[0];
    } else {
        strcpy(_displayTypeName, "NTSC");
        
        numVideoModes = (sizeof(ntscVideoModes) / sizeof(ntscVideoModes[0]));
        
        for (i = 0; i < (numVideoModes - 1) ; i++) {
            ntscVideoModes[i].pnext = &ntscVideoModes[i+1];
        }
        
        // Terminated the list. 
        ntscVideoModes[numVideoModes - 1].pnext = NULL;
        
        // add the video modes at the start of the mode list
        videoModes = &ntscVideoModes[0];     
    }
        
    
    
    // Load default mode (for the current display type).   
    defaultVideoModeIndex = VID_LoadDefaultMode();

    VID_SetMode(defaultVideoModeIndex, palette);
    
    
	vid_menudrawfn = VID_MenuDraw;
	vid_menukeyfn = VID_MenuKey;    
}

void VID_Shutdown(void) {
    VID_UnloadGFXMode();
}





/*
=================
VID_GetModeDescription
=================
*/
char *VID_GetModeDescription (int mode) {
	vmode_t		*pv;

	pv = VID_GetModePtr(mode);

	return pv->name;
}





static int	vid_line, vid_wmodes;

typedef struct
{
	int		modenum;
	char	*desc;
	int		iscur;
	int		width;
} modedesc_t;

#define MAX_COLUMN_SIZE		5
#define MODE_AREA_HEIGHT	(MAX_COLUMN_SIZE + 6)
#define MAX_MODEDESCS		(MAX_COLUMN_SIZE*3)

static modedesc_t	modedescs[MAX_MODEDESCS];

#define VID_ROW_SIZE	3

/*
================
VID_MenuDraw
================
*/
void VID_MenuDraw (void)
{
	qpic_t		*p;
	char		*ptr;
	int			i, j, k, column, row, dup, dupmode;
	char		temp[100];
	vmode_t		*pv;
	modedesc_t	tmodedesc;

	p = Draw_CachePic ("gfx/vidmodes.lmp");
	M_DrawPic ( (320-p->width)/2, 4, p);

	for (i=0 ; i<3 ; i++)
	{
		ptr = VID_GetModeDescription(i);
		modedescs[i].modenum = i;
		modedescs[i].desc = ptr;
		modedescs[i].iscur = 0;

		if (currentVideoModeIndex == i)
			modedescs[i].iscur = 1;
	}

	vid_wmodes = 3;
	
	for (i=3 ; i<numVideoModes ; i++)
	{
		ptr = VID_GetModeDescription(i);
		pv = VID_GetModePtr(i);

	    // we only have room for 15 fullscreen modes!
		if (ptr)
		{
			dup = 0;

			for (j=3 ; j<vid_wmodes ; j++)
			{
				if (!strcmp (modedescs[j].desc, ptr))
				{
					dup = 1;
					dupmode = j;
					break;
				}
			}

			if (dup || (vid_wmodes < MAX_MODEDESCS))       
			{
				if (!dup)
				{
					if (dup)
					{
						k = dupmode;
					}
					else
					{
						k = vid_wmodes;
					}

					modedescs[k].modenum = i;
					modedescs[k].desc = ptr;
					modedescs[k].iscur = 0;
					modedescs[k].width = pv->width;

					if (i == currentVideoModeIndex)
						modedescs[k].iscur = 1;

					if (!dup)
						vid_wmodes++;
				}
			}
		}
	}

    // sort the modes on width
	for (i=3 ; i<(vid_wmodes-1) ; i++)
	{
		for (j=(i+1) ; j<vid_wmodes ; j++)
		{
			if (modedescs[i].width > modedescs[j].width)
			{
				tmodedesc = modedescs[i];
				modedescs[i] = modedescs[j];
				modedescs[j] = tmodedesc;
			}
		}
	}


	//M_Print (13*8, 36, "Windowed Modes");

	column = 16;
	row = 36+2*8;

	for (i=0 ; i<3; i++)
	{
		if (modedescs[i].iscur)
			M_PrintWhite (column, row, modedescs[i].desc);
		else
			M_Print (column, row, modedescs[i].desc);

		column += 13*8;
	}

	if (vid_wmodes > 3)
	{
		//M_Print (12*8, 36+4*8, "Fullscreen Modes");

		column = 16;
		row = 36+6*8;

		for (i=3; i<vid_wmodes ; i++)
		{
			if (modedescs[i].iscur)
				M_PrintWhite (column, row, modedescs[i].desc);
			else
				M_Print (column, row, modedescs[i].desc);

			column += 13*8;

			if (((i - 3) % VID_ROW_SIZE) == (VID_ROW_SIZE - 1))
			{
				column = 16;
				row += 8;
			}
		}
	}

    // line cursor
    sprintf (temp, "Press Enter to set %s mode", _displayTypeName);
	M_Print (7*8, 36 + MODE_AREA_HEIGHT * 8 + 8, temp);

	ptr = VID_GetModeDescription(currentVideoModeIndex);

	if (ptr)
	{
		sprintf (temp, "D to set default: %s", ptr);
		M_Print (2*8, 36 + MODE_AREA_HEIGHT * 8 + 8*5, temp);
	}

	ptr = VID_GetModeDescription(defaultVideoModeIndex);

	if (ptr)
	{
		sprintf (temp, "Current default: %s", ptr);
		M_Print (3*8, 36 + MODE_AREA_HEIGHT * 8 + 8*6, temp);
	}

	M_Print (15*8, 36 + MODE_AREA_HEIGHT * 8 + 8*8, "Esc to exit");

	row = 36 + 2*8 + (vid_line / VID_ROW_SIZE) * 8;
	column = 8 + (vid_line % VID_ROW_SIZE) * 13*8;

	if (vid_line >= 3)
		row += 3*8;

	M_DrawCharacter (column, row, 12+((int)(realtime*4)&1));
}


/*
================
VID_MenuKey
================
*/
void VID_MenuKey (int key)
{
	switch (key)
	{
	case K_ESCAPE:
		S_LocalSound ("misc/menu1.wav");
		M_Menu_Options_f ();
		break;

	case K_LEFTARROW:
		S_LocalSound ("misc/menu1.wav");
		vid_line = ((vid_line / VID_ROW_SIZE) * VID_ROW_SIZE) +
				   ((vid_line + 2) % VID_ROW_SIZE);

		if (vid_line >= vid_wmodes)
			vid_line = vid_wmodes - 1;
		break;

	case K_RIGHTARROW:
		S_LocalSound ("misc/menu1.wav");
		vid_line = ((vid_line / VID_ROW_SIZE) * VID_ROW_SIZE) +
				   ((vid_line + 4) % VID_ROW_SIZE);

		if (vid_line >= vid_wmodes)
			vid_line = (vid_line / VID_ROW_SIZE) * VID_ROW_SIZE;
		break;

	case K_UPARROW:
		S_LocalSound ("misc/menu1.wav");
		vid_line -= VID_ROW_SIZE;

		if (vid_line < 0)
		{
			vid_line += ((vid_wmodes + (VID_ROW_SIZE - 1)) /
					VID_ROW_SIZE) * VID_ROW_SIZE;

			while (vid_line >= vid_wmodes)
				vid_line -= VID_ROW_SIZE;
		}
		break;

	case K_DOWNARROW:
		S_LocalSound ("misc/menu1.wav");
		vid_line += VID_ROW_SIZE;

		if (vid_line >= vid_wmodes)
		{
			vid_line -= ((vid_wmodes + (VID_ROW_SIZE - 1)) /
					VID_ROW_SIZE) * VID_ROW_SIZE;

			while (vid_line < 0)
				vid_line += VID_ROW_SIZE;
		}
		break;

	case K_ENTER:
		S_LocalSound ("misc/menu1.wav");
		VID_SetMode (modedescs[vid_line].modenum, vid_current_palette);
		break;

	case 'D':
	case 'd':
		S_LocalSound ("misc/menu1.wav");
		VID_SaveDefaultMode(currentVideoModeIndex);
		break;

	default:
		break;
	}
}












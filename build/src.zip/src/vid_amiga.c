/*
 Copyright (C) 1996-1997 Id Software, Inc.

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 See the GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 
 */

// Amiga includes.
#include <proto/exec.h>
#include <proto/intuition.h>
#include <proto/graphics.h>

#ifdef VIDEO_DRIVER_RTG
#include <cybergraphics/cybergraphics.h>
#include <proto/cybergraphics.h>
#else
#include "amiga_c2p_aga.h"
#endif

#include "quakedef.h"
#include "d_local.h"
#include "vid_amiga.h"

/** Hardware window */
struct Window* _hardwareWindow = NULL;

/** Hardware screen */
static struct Screen* _hardwareScreen = NULL;

static UWORD _emptypointer[] = { 0x0000, 0x0000, /* reserved, must be NULL */
0x0000, 0x0000, /* 1 row of image data */
0x0000, 0x0000 /* reserved, must be NULL */
};

#define AMIGA_DISPLAY_DEPTH         8

#ifdef VIDEO_DRIVER_AGA
#define DEFAULT_VIDEO_MODE_INDEX    0
#endif

static int _closeWb = 0;
static int _wbClosed = 0;

unsigned short d_8to16table[256];	// not used in 8 bpp mode
unsigned d_8to24table[256];	// not used in 8 bpp mode

static byte* vid_surfcache = NULL;
static int vid_highhunkmark = 0;
static pixel_t* vid_buffer = NULL;
static byte vid_current_palette[768];	// save for mode changes

#ifndef VIDEO_DRIVER_RTG
    typedef enum {
      PAL_DISPLAY_TYPE,
      NTSC_DISPLAY_TYPE
    } DisplayType_t;
    
    static DisplayType_t _displayType = PAL_DISPLAY_TYPE;
#endif

static char _displayTypeName[5];

static unsigned numVideoModes = 0;

#ifdef VIDEO_DRIVER_RTG
struct Library* CyberGfxBase = NULL;
static vmode_t** rtgVideoModes = NULL;
#else
    static struct ScreenBuffer *sbuffer[2] = {NULL, NULL};
    static void *c2p[2] = {NULL, NULL};

    static BYTE _currentScreenBuffer = 0;
    
    static vmode_t palVideoModes[] = {
    {
    	NULL,
    	"320x200",
    	320, 200, 320, 2
    },
    {
    	NULL,
    	"320x240",
        320, 240, 320, 2
    },
    {
    	NULL,
    	"320x256",
        320, 256, 320, 2
    }
    };
    
    static vmode_t ntscVideoModes[] = {
    {
    	NULL,
    	"320x200",
    	320, 200, 320, 2
    }, 
    {
    	NULL,
    	"640x200",
        640, 200, 640, 2
    },
    {
    	NULL,
    	"1280x200",
        1280, 200, 1280, 2
    }
    };
#endif

static unsigned currentVideoModeIndex = 0;
static unsigned defaultVideoModeIndex = 0;

static vmode_t* videoModes = NULL;
static vmode_t* currentVideoMode = NULL;

extern void M_DrawCharacter(int cx, int line, int num);
extern void M_Print(int cx, int cy, char* str);
extern void M_PrintWhite(int cx, int cy, char* str);
extern void M_DrawPic(int x, int y, qpic_t* pic);
extern void M_Menu_Options_f(void);

#ifdef VIDEO_DRIVER_RTG
static void VID_buildScreenModeListRTG(void) {
	int i;
	ULONG nextid;
	DisplayInfoHandle handle;

	// Reset.
	numVideoModes = 0;

	nextid = NextDisplayInfo(INVALID_ID);

	while (nextid != INVALID_ID) {
		if (IsCyberModeID(nextid)) {
			handle = FindDisplayInfo(nextid);
			if (handle) {
				struct DimensionInfo info;

				if (GetDisplayInfoData(handle, (UBYTE* )&info, sizeof(info), DTAG_DIMS, 0)) {
					if (info.MaxDepth == AMIGA_DISPLAY_DEPTH) {
						int allowed = 0;
						
						// Need to filter the many (many) screen resolutions available on PiStorm.
                        if ((info.Nominal.MaxX + 1) == 320) {
                            if (((info.Nominal.MaxY + 1) == 200) || ((info.Nominal.MaxY + 1) == 240) || ((info.Nominal.MaxY + 1) == 256)) {
						        allowed = 1;
                            }
                        }

                        if ((info.Nominal.MaxX + 1) == 640) {
                            if (((info.Nominal.MaxY + 1) == 400) || ((info.Nominal.MaxY + 1) == 480)) {
						        allowed = 1;
                            }
                        }

                        if ((info.Nominal.MaxX + 1) == 800) {
                            if ((info.Nominal.MaxY + 1) == 600) {
						        allowed = 1;
                            }
                        }

                        if ((info.Nominal.MaxX + 1) == 1024) {
                            if ((info.Nominal.MaxY + 1) == 768) {
						        allowed = 1;
                            }
                        }

                        if ((info.Nominal.MaxX + 1) == 1280) {
                            if ((info.Nominal.MaxY + 1) == 720) {
						        allowed = 1;
                            }
                        }

                        if ((info.Nominal.MaxX + 1) == 1280) {
                            if ((info.Nominal.MaxY + 1) == 1024) {
						        allowed = 1;
                            }
                        }

                        if (allowed) {
    						// Check to see if this allowed mode is already stored.
    						int found = 0;
    						for (i = 0; i < numVideoModes; i++) {
    							if (rtgVideoModes[i]->width == (info.Nominal.MaxX + 1) && rtgVideoModes[i]->height == (info.Nominal.MaxY + 1)) {
    								found = 1;
    								break;
    							}                             
    						}
    
    						if (!found) {
    							// Mode not stored already, store it.
    							numVideoModes++;
    
    							rtgVideoModes = (vmode_t**) realloc(rtgVideoModes, (numVideoModes + 1) * sizeof(vmode_t*));
    							rtgVideoModes[numVideoModes] = NULL;
    
    							if (rtgVideoModes) {
    								rtgVideoModes[numVideoModes - 1] = (vmode_t*) malloc(sizeof(vmode_t));
    
    								if (rtgVideoModes[numVideoModes - 1] == NULL) {
    									break;
                                    }
    
    								rtgVideoModes[numVideoModes - 1]->width = info.Nominal.MaxX + 1;
    								rtgVideoModes[numVideoModes - 1]->height = info.Nominal.MaxY + 1;
    
    								rtgVideoModes[numVideoModes - 1]->name = (char*) malloc(64);
    								sprintf(rtgVideoModes[numVideoModes - 1]->name, "%dx%d", rtgVideoModes[numVideoModes - 1]->width,
    										rtgVideoModes[numVideoModes - 1]->height);
    
    								rtgVideoModes[numVideoModes - 1]->rowbytes = rtgVideoModes[numVideoModes - 1]->width;
    								rtgVideoModes[numVideoModes - 1]->numpages = 1;
    							}
    						}
                        }
					}
				}
			}
		}

		nextid = NextDisplayInfo(nextid);
	}
}
#endif

void VID_SetPalette(unsigned char* palette) {
	int i;
	ULONG v;
	static ULONG colourtable[1 + 3 * 256 + 1];

	// Save a copy of the palette for mode changes.
	if (palette != vid_current_palette) {
		Q_memcpy(vid_current_palette, palette, 768);
	}

	colourtable[0] = (256 << 16) + 0;
	for (i = 0; i < 3 * 256; i++) {
		v = *palette++;
		v += (v << 8);
		v += (v << 16);
		colourtable[i + 1] = v;
	}

	colourtable[1 + 3 * 256] = 0;
	LoadRGB32(&_hardwareScreen->ViewPort, colourtable);
}

void VID_ShiftPalette(unsigned char* palette) {
	VID_SetPalette(palette);
}

static vmode_t* VID_GetModePtr(unsigned modenum) {
	vmode_t* pv;

	pv = videoModes;
	if (!pv) {
		Sys_Error("VID_GetModePtr: empty video mode list");
	}

	while (modenum--) {
		pv = pv->pnext;
		if (!pv) {
			Sys_Error("VID_GetModePtr: Corrupt video mode list detected");
		}
	}

	return pv;
}

static void VID_UnloadGFXMode(void) {

#ifndef VIDEO_DRIVER_RTG
    if (c2p[0]) {
        c2p8_deinit_stub(c2p[0]);
        c2p[0] = NULL;
    }

    if (c2p[1]) {
        c2p8_deinit_stub(c2p[1]);
        c2p[1] = NULL;
    }
#endif

	if (_hardwareWindow) {
		ClearPointer(_hardwareWindow);
		CloseWindow(_hardwareWindow);
		_hardwareWindow = NULL;
	}

#ifndef VIDEO_DRIVER_RTG
    if (sbuffer[0] != NULL) {
        ChangeScreenBuffer (_hardwareScreen, sbuffer[0]);
        WaitTOF();
        WaitTOF();
        FreeScreenBuffer (_hardwareScreen, sbuffer[0]);
        sbuffer[0] = NULL;
    }
    
    if (sbuffer[1] != NULL) {
        FreeScreenBuffer (_hardwareScreen, sbuffer[1]);
        sbuffer[1] = NULL;
    }
#endif

	if (_hardwareScreen) {
		CloseScreen(_hardwareScreen);
		_hardwareScreen = NULL;
	}

	if (_wbClosed) {
		OpenWorkBench();
		_wbClosed = 0;
	}

	// Chunky back buffer.
	if (vid_buffer) {
		free(vid_buffer);
		vid_buffer = NULL;
	}
}

#ifdef VIDEO_DRIVER_RTG
static struct Screen* VID_CreateHardwareScreenRTG(unsigned width, unsigned height) {
	struct Screen* screen = NULL;
	ULONG modeId = INVALID_ID;

	// Choose the best mode.
	modeId = BestCModeIDTags(CYBRBIDTG_Depth, AMIGA_DISPLAY_DEPTH, CYBRBIDTG_NominalWidth, width, CYBRBIDTG_NominalHeight, height,
			TAG_DONE);

	// Verify the mode choosen.
	if (modeId != INVALID_ID) {
		if (GetCyberIDAttr(CYBRIDATTR_DEPTH, modeId) != AMIGA_DISPLAY_DEPTH) {
			modeId = INVALID_ID;
		}

		if (GetCyberIDAttr(CYBRIDATTR_WIDTH, modeId) != width) {
			modeId = INVALID_ID;
		}

		if (GetCyberIDAttr(CYBRIDATTR_HEIGHT, modeId) < height) {
			modeId = INVALID_ID;
		}
	}

	if (modeId != INVALID_ID) {
		screen = (struct Screen*) OpenScreenTags(NULL, SA_Depth, AMIGA_DISPLAY_DEPTH, SA_DisplayID, modeId, SA_Top, 0, SA_Left, 0, SA_Width,
				width, SA_Height, height, SA_Type, CUSTOMSCREEN, SA_Quiet, TRUE, SA_ShowTitle, FALSE, SA_Draggable, FALSE, SA_Exclusive,
				TRUE, SA_AutoScroll, FALSE, TAG_END);
	}

	return screen;
}
#else
static struct Screen* VID_CreateHardwareScreenAGA(unsigned width, unsigned height)
{
    struct Screen* screen = NULL;
    ULONG modeId = INVALID_ID;
    ULONG monitorId = PAL_MONITOR_ID;
    DisplayInfoHandle handle;
	struct DimensionInfo dimsinfo;    
    
    if (_displayType == NTSC_DISPLAY_TYPE) {
        monitorId = NTSC_MONITOR_ID;
    }

    modeId = BestModeID(BIDTAG_NominalWidth, width,
                        BIDTAG_NominalHeight, height,
            	        BIDTAG_DesiredWidth, width,
            	        BIDTAG_DesiredHeight, height,
            	        BIDTAG_Depth, AMIGA_DISPLAY_DEPTH,
            	        BIDTAG_MonitorID, monitorId,
            	        TAG_END);
            	        
	// Verify the mode choosen.
	if (modeId != INVALID_ID) {
		if ((handle = FindDisplayInfo(modeId)) == NULL) {
			modeId = INVALID_ID;
		}
    }

    if (modeId != INVALID_ID) {
		if (GetDisplayInfoData(handle, (UBYTE *)&dimsinfo, sizeof(dimsinfo), DTAG_DIMS, 0) == 0) {
			modeId = INVALID_ID;
		}
    }
    
    if (modeId != INVALID_ID) {
		if (dimsinfo.MaxDepth != AMIGA_DISPLAY_DEPTH) {
		   modeId = INVALID_ID;
		}

		if ((dimsinfo.Nominal.MaxX + 1) != width) {
		   modeId = INVALID_ID;
		}

		if ((dimsinfo.Nominal.MaxY + 1) < height) {
		   modeId = INVALID_ID;
		}
	}

    if (modeId != INVALID_ID) {
    	screen = (struct Screen*) OpenScreenTags(NULL,
                         SA_Depth, AMIGA_DISPLAY_DEPTH,
                         SA_DisplayID, modeId,
                         SA_Top, 0,
                         SA_Left, 0,
                         SA_Width, width,
    					 SA_Height, height,
						 SA_Type, CUSTOMSCREEN,
                         SA_Quiet, TRUE,
    					 SA_ShowTitle, FALSE,
    					 SA_Draggable, FALSE,
                         SA_Exclusive, TRUE,
    					 SA_AutoScroll, FALSE,
						 TAG_END);
    }

    return screen;
}
#endif

static struct Window* VID_CreateHardwareWindow(unsigned width, unsigned height) {
	return OpenWindowTags(NULL, WA_Left, 0, WA_Top, 0, WA_Width, width, WA_Height, height, WA_CustomScreen, (ULONG )_hardwareScreen,
			WA_Backdrop, TRUE, WA_Borderless, TRUE, WA_Activate, TRUE, WA_SimpleRefresh, TRUE, WA_NoCareRefresh, TRUE, WA_ReportMouse, TRUE,
			WA_RMBTrap, TRUE, WA_IDCMP, IDCMP_RAWKEY|IDCMP_MOUSEMOVE|IDCMP_DELTAMOVE|IDCMP_MOUSEBUTTONS, TAG_END);
}

static qboolean VID_AllocBuffers(unsigned width, unsigned height) {
	int tsize, tbuffersize;

	tbuffersize = width * height * sizeof(*d_pzbuffer);

	tsize = D_SurfaceCacheForRes(width, height);

	tbuffersize += tsize;

	if (d_pzbuffer) {
		D_FlushCaches();
		Hunk_FreeToHighMark(vid_highhunkmark);
		d_pzbuffer = NULL;
	}

	vid_highhunkmark = Hunk_HighMark();

	d_pzbuffer = Hunk_HighAllocName(tbuffersize, "video");

	vid_surfcache = (byte*) d_pzbuffer + width * height * sizeof(*d_pzbuffer);

	D_InitCaches(vid_surfcache, tsize);

	return true;
}

static qboolean VID_LoadGFXMode(vmode_t* newVideoMode) {
#ifdef VIDEO_DRIVER_RTG    
	_hardwareScreen = VID_CreateHardwareScreenRTG(newVideoMode->width, newVideoMode->height);
	if (!_hardwareScreen) {
		Sys_Printf("VID_LoadGFXMode: Could not create screen\n");
		return false;
	}
#else
	_hardwareScreen = VID_CreateHardwareScreenAGA(newVideoMode->width, newVideoMode->height);
	if (!_hardwareScreen) {
        Sys_Printf("VID_LoadGFXMode: Could not create screen\n");
		return false;
	}

    sbuffer[0] = AllocScreenBuffer(_hardwareScreen, NULL, SB_SCREEN_BITMAP);
    if (sbuffer[0] == NULL) {
        Sys_Printf("VID_LoadGFXMode: Could not create screen buffer\n");
        return false;
    }
    
    sbuffer[1] = AllocScreenBuffer(_hardwareScreen, NULL, 0);
    if (sbuffer[1] == NULL) {
        Sys_Printf ("VID_LoadGFXMode: Could not create screen buffer\n");
        return false;
    }
   
    c2p[0] = c2p8_reloc_stub(sbuffer[0]->sb_BitMap);
    c2p[1] = c2p8_reloc_stub(sbuffer[1]->sb_BitMap);

    _currentScreenBuffer = 1;
#endif

	_hardwareWindow = VID_CreateHardwareWindow(newVideoMode->width, newVideoMode->height);
	if (!_hardwareWindow) {
		Sys_Printf("VID_LoadGFXMode: Could not create window\n");
		return false;
	}

	if (_closeWb) {
		_wbClosed = CloseWorkBench();
	}

	// Hide WB mouse pointer.
	SetPointer(_hardwareWindow, _emptypointer, 1, 16, 0, 0);

	// Allocate the buffers.
	return VID_AllocBuffers(newVideoMode->width, newVideoMode->height);
}

void VID_SetMode(unsigned newVideoModeIndex, unsigned char* palette) {
	vmode_t* newVideoMode;

	if (newVideoModeIndex >= numVideoModes) {
		Sys_Error("VID_SetMode: Invalid video mode requested");
	}

	if (currentVideoMode != NULL) {
		if (newVideoModeIndex == currentVideoModeIndex) {
			// already in the desired mode
			return;
		}
	}

	newVideoMode = VID_GetModePtr(newVideoModeIndex);
	if (!newVideoMode) {
		Sys_Error("VID_SetMode: Corrupt video mode list detected");
	}

	VID_UnloadGFXMode();

	if (!VID_LoadGFXMode(newVideoMode)) {
		if (currentVideoMode == NULL) {
			// Failed on initial mode.
			Sys_Error("VID_SetMode: Unable to set initial mode");
		}

		// Try to restore the old mode.
		if (!VID_LoadGFXMode(currentVideoMode)) {
			Sys_Error("VID_SetMode: Unable to restore old mode");
		}

		// Restore of old mode was successful.
		VID_SetPalette(palette);

		Sys_Error("VID_SetMode: Failed to set mode %d", newVideoMode);
		return;
	}

	// Setting a new mode was successful.
	currentVideoMode = newVideoMode;
	currentVideoModeIndex = newVideoModeIndex;

	if (vid_buffer) {
		free(vid_buffer);
		vid_buffer = NULL;
	}

	if ((vid_buffer = (pixel_t*) malloc(sizeof(pixel_t) * currentVideoMode->width * currentVideoMode->height)) == NULL) {
		Sys_Error("VID_SetMode: Out of memory");
	}

	vid.buffer = vid_buffer;

	vid.width = currentVideoMode->width;
	vid.height = currentVideoMode->height;
	vid.aspect = ((float) vid.height / (float) vid.width) * (320.0 / 240.0);
	vid.rowbytes = currentVideoMode->rowbytes;
	vid.numpages = currentVideoMode->numpages;

	vid.colormap = host_colormap;
	vid.fullbright = 256 - LittleLong(*((int*) vid.colormap + 2048));

	vid.maxwarpwidth = WARP_WIDTH;
	vid.maxwarpheight = WARP_HEIGHT;

	vid.conbuffer = vid_buffer;
	vid.conrowbytes = currentVideoMode->rowbytes;
	vid.conwidth = currentVideoMode->width;
	vid.conheight = currentVideoMode->height;

	vid.recalc_refdef = 1;

	VID_SetPalette(palette);
}

#ifdef VIDEO_DRIVER_RTG
static unsigned VID_LoadDefaultMode() {
	int modeId = INVALID_ID;
	int i;

	// Load mode file.
	FILE* modeFile;
	char fileName[50];

	sprintf(fileName, "%s_default.mode", _displayTypeName);

	modeFile = fopen(fileName, "r");
	if (modeFile != NULL) {
		fscanf(modeFile, "%u", &modeId);
		fclose(modeFile);
	}

	if ((modeId == INVALID_ID) || (modeId > (numVideoModes - 1))) {
        for (i = 0; i < numVideoModes; i++) {
		  if (rtgVideoModes[i]) {
                if (rtgVideoModes[i]->width == 640 && rtgVideoModes[i]->height == 480) {
                    modeId = i;
                    break;
                }
            } 
        }
	}
	
	if (modeId == INVALID_ID) {
        Sys_Error("VID_LoadDefaultMode: Could not find the default mode (640x480 8-bit)");
    }

	return modeId;
}
#else
static unsigned VID_LoadDefaultMode() {
	int modeId = INVALID_ID;

	// Load mode file.
	FILE* modeFile;
	char fileName[50];

	sprintf(fileName, "%s_default.mode", _displayTypeName);

	modeFile = fopen(fileName, "r");
	if (modeFile != NULL) {
		fscanf(modeFile, "%u", &modeId);
		fclose(modeFile);
	}

	if ((modeId == INVALID_ID) || (modeId > (numVideoModes - 1))) {
		modeId = DEFAULT_VIDEO_MODE_INDEX;
	}

	return modeId;
}
#endif

static void VID_SaveDefaultMode(unsigned modeIndex) {
	FILE* modeFile;
	char fileName[50];

	defaultVideoModeIndex = modeIndex;

	sprintf(fileName, "%s_default.mode", _displayTypeName);

	modeFile = fopen(fileName, "w");
	if (modeFile != NULL) {
		fprintf(modeFile, "%u", defaultVideoModeIndex);
		fclose(modeFile);
	}
}

#ifdef VIDEO_DRIVER_RTG
void VID_Update(vrect_t* rects) {
	UBYTE* base_address;
	APTR video_bitmap_handle = LockBitMapTags(_hardwareScreen->ViewPort.RasInfo->BitMap, LBMI_BASEADDRESS, (ULONG )&base_address, TAG_DONE);
	if (video_bitmap_handle) {
		CopyMemQuick(vid.buffer, base_address, vid.width * rects->height);
		UnLockBitMap(video_bitmap_handle);
	}
}
#else
void VID_Update(vrect_t *rects)
{         
    c2p8_stub(c2p[_currentScreenBuffer], sbuffer[_currentScreenBuffer]->sb_BitMap, vid.buffer, vid.width * rects->height);
    
    if (ChangeScreenBuffer (_hardwareScreen, sbuffer[_currentScreenBuffer])) {
	   _currentScreenBuffer = _currentScreenBuffer ^ 1;
    }
}
#endif

static char* VID_GetModeDescription(int mode) {
	vmode_t* pv;

	pv = VID_GetModePtr(mode);

	return pv->name;
}

static int vid_line, vid_wmodes;

typedef struct {
	int modenum;
	char* desc;
	int iscur;
	int width;
} modedesc_t;

#define MAX_COLUMN_SIZE		5
#define MODE_AREA_HEIGHT	(MAX_COLUMN_SIZE + 6)
#define MAX_MODEDESCS		(MAX_COLUMN_SIZE*3)

static modedesc_t modedescs[MAX_MODEDESCS];

#define VID_ROW_SIZE	3

void VID_MenuDraw(void) {
	qpic_t* p;
	char* ptr;
	int i, j, k, column, row, dup, dupmode;
	char temp[100];
	vmode_t* pv;
	modedesc_t tmodedesc;

	p = Draw_CachePic("gfx/vidmodes.lmp");
	M_DrawPic((320 - p->width) / 2, 4, p);

	for (i = 0; i < 3; i++) {
		ptr = VID_GetModeDescription(i);
		modedescs[i].modenum = i;
		modedescs[i].desc = ptr;
		modedescs[i].iscur = 0;

		if (currentVideoModeIndex == i)
			modedescs[i].iscur = 1;
	}

	vid_wmodes = 3;

	for (i = 3; i < numVideoModes; i++) {
		ptr = VID_GetModeDescription(i);
		pv = VID_GetModePtr(i);

		// we only have room for 15 fullscreen modes!
		if (ptr) {
			dup = 0;

			for (j = 3; j < vid_wmodes; j++) {
				if (!strcmp(modedescs[j].desc, ptr)) {
					dup = 1;
					dupmode = j;
					break;
				}
			}

			if (dup || (vid_wmodes < MAX_MODEDESCS)) {
				if (!dup) {
					if (dup) {
						k = dupmode;
					} else {
						k = vid_wmodes;
					}

					modedescs[k].modenum = i;
					modedescs[k].desc = ptr;
					modedescs[k].iscur = 0;
					modedescs[k].width = pv->width;

					if (i == currentVideoModeIndex)
						modedescs[k].iscur = 1;

					if (!dup)
						vid_wmodes++;
				}
			}
		}
	}

	// sort the modes on width
	for (i = 3; i < (vid_wmodes - 1); i++) {
		for (j = (i + 1); j < vid_wmodes; j++) {
			if (modedescs[i].width > modedescs[j].width) {
				tmodedesc = modedescs[i];
				modedescs[i] = modedescs[j];
				modedescs[j] = tmodedesc;
			}
		}
	}

	//M_Print (13*8, 36, "Windowed Modes");

	column = 16;
	row = 36 + 2 * 8;

	for (i = 0; i < 3; i++) {
		if (modedescs[i].iscur)
			M_PrintWhite(column, row, modedescs[i].desc);
		else
			M_Print(column, row, modedescs[i].desc);

		column += 13 * 8;
	}

	if (vid_wmodes > 3) {
		//M_Print (12*8, 36+4*8, "Fullscreen Modes");

		column = 16;
		row = 36 + 6 * 8;

		for (i = 3; i < vid_wmodes; i++) {
			if (modedescs[i].iscur)
				M_PrintWhite(column, row, modedescs[i].desc);
			else
				M_Print(column, row, modedescs[i].desc);

			column += 13 * 8;

			if (((i - 3) % VID_ROW_SIZE) == (VID_ROW_SIZE - 1)) {
				column = 16;
				row += 8;
			}
		}
	}

	// line cursor
	sprintf(temp, "Press Enter to set %s mode", _displayTypeName);
	M_Print(7 * 8, 36 + MODE_AREA_HEIGHT * 8 + 8, temp);

	ptr = VID_GetModeDescription(currentVideoModeIndex);

	if (ptr) {
		sprintf(temp, "D to set default: %s", ptr);
		M_Print(2 * 8, 36 + MODE_AREA_HEIGHT * 8 + 8 * 5, temp);
	}

	ptr = VID_GetModeDescription(defaultVideoModeIndex);

	if (ptr) {
		sprintf(temp, "Current default: %s", ptr);
		M_Print(3 * 8, 36 + MODE_AREA_HEIGHT * 8 + 8 * 6, temp);
	}

	M_Print(15 * 8, 36 + MODE_AREA_HEIGHT * 8 + 8 * 8, "Esc to exit");

	row = 36 + 2 * 8 + (vid_line / VID_ROW_SIZE) * 8;
	column = 8 + (vid_line % VID_ROW_SIZE) * 13 * 8;

	if (vid_line >= 3)
		row += 3 * 8;

	M_DrawCharacter(column, row, 12 + ((int) (realtime * 4) & 1));
}

void VID_MenuKey(int key) {
	switch (key) {
	case K_ESCAPE:
		S_LocalSound("misc/menu1.wav");
		M_Menu_Options_f();
		break;

	case K_LEFTARROW:
		S_LocalSound("misc/menu1.wav");
		vid_line = ((vid_line / VID_ROW_SIZE) * VID_ROW_SIZE) + ((vid_line + 2) % VID_ROW_SIZE);

		if (vid_line >= vid_wmodes)
			vid_line = vid_wmodes - 1;
		break;

	case K_RIGHTARROW:
		S_LocalSound("misc/menu1.wav");
		vid_line = ((vid_line / VID_ROW_SIZE) * VID_ROW_SIZE) + ((vid_line + 4) % VID_ROW_SIZE);

		if (vid_line >= vid_wmodes)
			vid_line = (vid_line / VID_ROW_SIZE) * VID_ROW_SIZE;
		break;

	case K_UPARROW:
		S_LocalSound("misc/menu1.wav");
		vid_line -= VID_ROW_SIZE;

		if (vid_line < 0) {
			vid_line += ((vid_wmodes + (VID_ROW_SIZE - 1)) /
			VID_ROW_SIZE) * VID_ROW_SIZE;

			while (vid_line >= vid_wmodes)
				vid_line -= VID_ROW_SIZE;
		}
		break;

	case K_DOWNARROW:
		S_LocalSound("misc/menu1.wav");
		vid_line += VID_ROW_SIZE;

		if (vid_line >= vid_wmodes) {
			vid_line -= ((vid_wmodes + (VID_ROW_SIZE - 1)) /
			VID_ROW_SIZE) * VID_ROW_SIZE;

			while (vid_line < 0)
				vid_line += VID_ROW_SIZE;
		}
		break;

	case K_ENTER:
		S_LocalSound("misc/menu1.wav");
		VID_SetMode(modedescs[vid_line].modenum, vid_current_palette);
		break;

	case 'D':
	case 'd':
		S_LocalSound("misc/menu1.wav");
		VID_SaveDefaultMode(currentVideoModeIndex);
		break;

	default:
		break;
	}
}

void VID_Init(unsigned char* palette) {
	int i;

	if (COM_CheckParm("-closewb")) {
		_closeWb = 1;
	}

	// link together all the display modes
#ifdef VIDEO_DRIVER_RTG
	strcpy(_displayTypeName, "RTG");

	CyberGfxBase = OpenLibrary("cybergraphics.library", 0);
	if (!CyberGfxBase) {
		Sys_Error("Can't open cybergraphics.library");
	}

	VID_buildScreenModeListRTG();
	if (numVideoModes == 0) {
		Sys_Error("Couldn't find any supported display modes");
	}

	for (i = 0; i < (numVideoModes - 1); i++) {
		rtgVideoModes[i]->pnext = rtgVideoModes[i + 1];
	}

	// Terminated the list.
	rtgVideoModes[numVideoModes - 1]->pnext = NULL;

	// add the video modes at the start of the mode list
	videoModes = rtgVideoModes[0];
#else
    i = COM_CheckParm ("-displaytype");
	if (i && i < com_argc-1) {
       	if (strcmp(com_argv[i+1], "NTSC") == 0) {
            _displayType = NTSC_DISPLAY_TYPE;
        }
	}
	
    // link together all the display modes
    if (_displayType == PAL_DISPLAY_TYPE) {
        strcpy(_displayTypeName, "PAL");
        
        numVideoModes = (sizeof(palVideoModes) / sizeof(palVideoModes[0]));
        
        for (i = 0; i < (numVideoModes - 1) ; i++) {
            palVideoModes[i].pnext = &palVideoModes[i+1];
        }
        
        // Terminated the list.
        palVideoModes[numVideoModes - 1].pnext = NULL;
        
        // add the video modes at the start of the mode list
        videoModes = &palVideoModes[0];
    }
    
    if (_displayType == NTSC_DISPLAY_TYPE) {
        strcpy(_displayTypeName, "NTSC");
        
        numVideoModes = (sizeof(ntscVideoModes) / sizeof(ntscVideoModes[0]));
        
        for (i = 0; i < (numVideoModes - 1) ; i++) {
            ntscVideoModes[i].pnext = &ntscVideoModes[i+1];
        }
        
        // Terminated the list. 
        ntscVideoModes[numVideoModes - 1].pnext = NULL;
        
        // add the video modes at the start of the mode list
        videoModes = &ntscVideoModes[0];     
    }
#endif

	// Load default mode (for the current display type).
	defaultVideoModeIndex = VID_LoadDefaultMode();

	VID_SetMode(defaultVideoModeIndex, palette);

	vid_menudrawfn = VID_MenuDraw;
	vid_menukeyfn = VID_MenuKey;
}

void VID_Shutdown(void) {
#ifdef VIDEO_DRIVER_RTG
	int i;
#endif

	VID_UnloadGFXMode();

#ifdef VIDEO_DRIVER_RTG
	// Free up screen modes.
	for (i = 0; i < numVideoModes; i++) {
		if (rtgVideoModes[i]) {
			if (rtgVideoModes[i]->name) {
				free(rtgVideoModes[i]->name);
				rtgVideoModes[i]->name = NULL;
			}

			free(rtgVideoModes[i]);
			rtgVideoModes[i] = NULL;
		}
	}

	numVideoModes = 0;

	if (CyberGfxBase) {
		CloseLibrary(CyberGfxBase);
		CyberGfxBase = NULL;
	}
#endif
}
